CTEST_CVS_CHECKOUT
------------------

.. versionadded:: 3.1

Deprecated.  Use :variable:`CTEST_CHECKOUT_COMMAND` instead.
