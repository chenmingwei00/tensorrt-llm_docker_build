MSVC80
------

Discouraged.  Use the :variable:`MSVC_VERSION` variable instead.

``True`` when using the Microsoft Visual Studio ``v80`` toolset
(``cl`` version 14) or another compiler that simulates it.
