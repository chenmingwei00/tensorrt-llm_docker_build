CTEST_DROP_SITE_CDASH
---------------------

.. versionadded:: 3.1

Specify the CTest ``IsCDash`` setting
in a :manual:`ctest(1)` dashboard client script.
