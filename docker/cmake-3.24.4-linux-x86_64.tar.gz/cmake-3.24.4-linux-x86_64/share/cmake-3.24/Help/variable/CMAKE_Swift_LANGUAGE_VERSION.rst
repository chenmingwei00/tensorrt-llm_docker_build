CMAKE_Swift_LANGUAGE_VERSION
----------------------------

.. versionadded:: 3.7

Set to the Swift language version number.  If not set, the oldest legacy
version known to be available in the host Xcode version is assumed:

* Swift ``4.0`` for Xcode 10.2 and above.
* Swift ``3.0`` for Xcode 8.3 and above.
* Swift ``2.3`` for Xcode 8.2 and below.
