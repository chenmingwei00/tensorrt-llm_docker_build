XCODE
-----

.. versionadded:: 3.7

``True`` when using :generator:`Xcode` generator.
