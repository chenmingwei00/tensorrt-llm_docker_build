CTEST_DROP_METHOD
-----------------

.. versionadded:: 3.1

Specify the CTest ``DropMethod`` setting
in a :manual:`ctest(1)` dashboard client script.
