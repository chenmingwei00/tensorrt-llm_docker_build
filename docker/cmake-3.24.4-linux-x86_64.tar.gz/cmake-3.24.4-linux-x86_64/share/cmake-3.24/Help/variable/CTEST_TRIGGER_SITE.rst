CTEST_TRIGGER_SITE
------------------

.. versionadded:: 3.1

Legacy option.  Not used.
