UNIX
----

Set to ``True`` when the target system is UNIX or UNIX-like
(e.g. :variable:`APPLE` and :variable:`CYGWIN`).  The
:variable:`CMAKE_SYSTEM_NAME` variable should be queried if
a more specific understanding of the target system is required.
