CTEST_USE_LAUNCHERS
-------------------

.. versionadded:: 3.1

Specify the CTest ``UseLaunchers`` setting
in a :manual:`ctest(1)` dashboard client script.
